
#include <iostream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
using namespace std;


class strCopied{
private:
    char* _strbuf;                                   
    int _length;  
public :
     strCopied(char* p = 0) throw() 
     {
        _strbuf=p;
        _length = 0;
     } 
    strCopied(const strCopied& copyObj)
    {
      int num=copyObj._length;
      _strbuf = new char [num];
      strcpy(_strbuf, copyObj._strbuf);
      _length = copyObj._length;       
    }
    strCopied& operator= (const strCopied &copyObj )
    { 
        if (this != &copyObj)
        {
            delete[] _strbuf;
            _strbuf = new char [copyObj._length];
            strcpy(_strbuf, copyObj._strbuf);
            _length = copyObj._length;       
        }
        return *this;
    }
strCopied(char* str,int len): _strbuf(str),_length(len){}
~strCopied()  
{

    delete[] _strbuf;
   
}

  int length() const{
	return _length;
}

char charAt(int index) const
{
	return _strbuf[index];
}


void reserve(int index)
{
	_strbuf = new char[index];
}

void append(char letter)
{
	_strbuf[_length] = letter;
	_length += 1;
}

void print()
{
    
    for (int i = 0; i < _length ; ++i)
    {
         cout<<*(_strbuf + i) ;
    }
    
}
};





