#include <iostream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
using namespace std;
class str_in_refCount{
private:
    struct counter 
    {
        counter(unsigned c = 1) :count(c) {}
        unsigned count;
    }* tempCounter;  
                                  
    char* _strbuf; 
    int _length;

    void FetcherFunction(counter* c) throw()
    { 
        tempCounter = c;
        if (c) ++c->count;
    }
    void releaseFunc()
    { 
        if (tempCounter) {
          if (tempCounter->count == 0) 
            {
                delete[] _strbuf;
                delete tempCounter;
            }
            --tempCounter;
        }
    }
public :
    str_in_refCount()throw():tempCounter(0),_length(0){}
    char* get()const throw(){return _strbuf;}
    str_in_refCount(const str_in_refCount& refCountObj): _length(refCountObj._length)
    {
        FetcherFunction(refCountObj.tempCounter);
    }
    str_in_refCount& operator= (const str_in_refCount &refCountObj )
    { 

        if (this != &refCountObj) 
        {
            releaseFunc();
            FetcherFunction(refCountObj.tempCounter);
        }
        _strbuf = refCountObj._strbuf;
        _length = refCountObj._length;
        return *this;
    }

    bool unique()   const throw()
        {return (tempCounter ? tempCounter->count == 1 : true);}


~str_in_refCount()  
{
    releaseFunc();
    
}



int length() const{
    return _length;
}


char charAt(int index) const
{
    return _strbuf[index];
}


void reserve(int index)
{
    _strbuf = new char[index];
    tempCounter = new counter();
}

void append(char letter)
{
    if(tempCounter->count > 1)
    {
        --tempCounter->count;
        tempCounter = new counter();
        char* temp = new char[_length];
        strncpy(temp,_strbuf,_length);
        _strbuf = new char[_length];
        strncpy(_strbuf,temp,_length);
        _strbuf[_length] = letter;
        _length += 1;
        cout<<"New Copy"<<endl;
        delete[] temp;
       

    }
    else
    {
        _strbuf[_length] = letter;    
        _length += 1;
    }
}

void print()
{
    
    for (int i = 0; i < _length; ++i)
    {
         cout<<*(_strbuf + i) ;
    }
}

    


};




