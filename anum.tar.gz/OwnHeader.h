#include <iostream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
using namespace std;
class str_in_ownedString	
{
private:
    bool sh;
    char* _strbuf;                                   
    int _length; 
public :
    str_in_ownedString(char* p = 0) throw(): sh(p!=0), _strbuf(p) {}

	str_in_ownedString(const str_in_ownedString& ownedObj) throw(): sh(ownedObj.sh), _strbuf(ownedObj.release()) {}

    str_in_ownedString& operator =(const str_in_ownedString &ownedObj )
    { 

    	if (&ownedObj != this) {
            if (_strbuf != ownedObj._strbuf)
            {
                if (sh)
                {
                	delete[] _strbuf;
                	delete _strbuf;
                }
                sh = ownedObj.sh;
            }
            else if (ownedObj.sh) sh = true;
            delete[] _strbuf;
            _strbuf = ownedObj.release();

            _length = ownedObj._length;
        }

        return *this;
    }
    char* release()  const throw()
    {
    	(const_cast<str_in_ownedString* >(this))->sh = false; 
    	return _strbuf;
    }

 str_in_ownedString(char* str,int len)
{
    _strbuf = str;
    _length = len;
}
 ~str_in_ownedString()  
{
	if (sh)
	{
		delete[] _strbuf;
	}
	delete _strbuf;
}
int  length() const{
	return _length;
}
char  charAt(int in) const
{
	return _strbuf[in];
}
void  reserve(int in)
{
	_strbuf = new char[in];
}
void  append(char  str)
{
	_strbuf[_length] =  str;
	_length += 1;
}
void  print()
{  
    for (int i = 0; i < _length+1 ; ++i)
    {
         cout<<*(_strbuf + i) ;
    }
    
}
};


