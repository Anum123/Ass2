#include <iostream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
using namespace std;
class str_in_refLink{
private:

    char* _strbuf; 
    int _length;
    
    str_in_refLink*   Pre_Pointer;
    str_in_refLink*   Next_Pointer;
    
    void fetched(const str_in_refLink& refLinkObj) throw()
    { 
        _strbuf = refLinkObj._strbuf;
        _length = refLinkObj._length;
        Next_Pointer = refLinkObj.Next_Pointer;
        Next_Pointer->Pre_Pointer = this;
        (const_cast<str_in_refLink*>(&refLinkObj))->Next_Pointer = this;
    }

    void releaseFunc()
    { 
        if (isUnique()) 
        	delete[] _strbuf;
        else
        {
            Pre_Pointer->Next_Pointer = Next_Pointer;
            Next_Pointer->Pre_Pointer = Pre_Pointer;
            Pre_Pointer = Next_Pointer = 0;
           
        }
       
    }

public :
    
    str_in_refLink(str_in_refLink* p = 0) throw()   : _strbuf(0) 
    {
        Pre_Pointer = Next_Pointer = this;
    }
    char* get() const throw()   
    {
    	return _strbuf;
    }
	str_in_refLink(const str_in_refLink& refLinkObj):_length(refLinkObj._length)
	{
        fetched(refLinkObj);
	}


    str_in_refLink& operator= (const str_in_refLink &refLinkObj )
    { 

    	if (this != &refLinkObj) {
            releaseFunc();
            fetched(refLinkObj);
        }
        return *this;
    }

    bool isUnique()   const throw()  
     {
     	if(Pre_Pointer == this && Next_Pointer == this)
     	{
     		return 1;
     	}
     	else
     	{
     		return 0;
     	}
     }


~str_in_refLink()  
{
	releaseFunc();	
}



int  length() const
{
	return _length;
}


char  charAt(int ind) const
{
	return _strbuf[ind];
}


void  reserve(int ind)
{
	_strbuf = new char[ind];
}

void  append(char str)
{
	if(isUnique())
	{
		_strbuf[_length] =  str;
		_length += 1;
	}
	else
	{
		char* temp = new char[_length];
		strncpy(temp,_strbuf,_length);
		releaseFunc();
		_strbuf = new char[_length];
		strncpy(_strbuf,temp,_length);
		_strbuf[_length] =  str;
		_length += 1;
		delete[] temp;
		Next_Pointer = Pre_Pointer = this;

	}
	
}
void  print()
{
    
    for (int i = 0; i < _length ; ++i)
    {
         cout<<*(_strbuf + i) ;
    }
}

};

