#include <iostream>
#include <string>
#include <stdio.h>
#include <iostream>
#include <assert.h>
#include "Copier.h"
#include "OwnHeader.h"
#include "COWheader.h"
#include "LinkedRef.h"
using namespace std;



class mainClasss
{
public:
	mainClasss(){};
	


	void length_Copied();
	void length_Owned();
	void length_RefCount();
	void length_RefLink();

	void Print_Copied();
	void Print_Owned();
	void Print_RefCount();
	void Print_RefLink();
	void Append_Copied();
	void Append_Owned();
	void Append_RefCount();
	void Append_RefLink();	



	
	void cons_Copied_Pointer();
	void cons_Owned_Pointer();
	void cons_RefCount_Pointer();
	void cons_RefLink_Pointer();	

};

void mainClasss::cons_Copied_Pointer()
{
	strCopied obj1;
	obj1.reserve(10);
	obj1.append('A');
	obj1.append('B');

	strCopied obj2(obj1);

	for(int i = 0; i < 2;++i)
	{
		if(obj1.charAt(i) != obj2.charAt(i))
		{
			cout<<"Test Failed"<<endl;
			return;
		}
	}
	cout <<"Test Passed"<<endl;
}



void mainClasss::cons_Owned_Pointer()
{
	str_in_ownedString* obj1 = new str_in_ownedString();
	obj1->reserve(10);
	obj1->append('A');
	str_in_ownedString* obj2 = new str_in_ownedString(*obj1);
	obj2->reserve(10);
	*obj2 = *obj1;

	for(int i = 0; i < 2;++i)
	{
		if(obj1->charAt(i) != obj2->charAt(i))
		{
			cout<<"Test Failed"<<endl;
			return;
		}
	}
	cout <<"Test Passed"<<endl;
	
}


void mainClasss::cons_RefCount_Pointer()
{
	str_in_refCount obj1;
	obj1.reserve(10);
	obj1.append('A');
	obj1.append('B');

	str_in_refCount op1;

	op1.reserve(10);

	op1 = obj1;

	for(int i = 0; i < 2;++i)
	{
		if(obj1.charAt(i) != op1.charAt(i))
		{
			cout<<"Test Failed"<<endl;
			return;
		}
	}
	cout <<"Test Passed"<<endl;

}


void mainClasss::cons_RefLink_Pointer()
{
	str_in_refLink* obj1 = new str_in_refLink();
	obj1->reserve(10);
	obj1->append('A');

	str_in_refLink* obj2 = new str_in_refLink();
	obj2->reserve(10);
	*obj1 = *obj2;

	for(int i = 0; i < 2;++i)
	{
		if(obj1->charAt(i) != obj2->charAt(i))
		{
			cout<<"Test Failed"<<endl;
			return;
		}
	}
	cout <<"Test Passed"<<endl;
	

}



void mainClasss::length_Copied()
{
	strCopied obj;
	obj.reserve(10);
	obj.append('A');
	int len = obj.length();
	if(len == 1)
		cout <<"Test Passed"<<endl;
	else
		cout <<"Test Failed"<<endl;
}



void mainClasss::length_Owned()
{
	str_in_ownedString* obj1 = new str_in_ownedString();
	obj1->reserve(10);
	obj1->append('A');

	int len = obj1->length();
	if(len == 1)
		cout <<"Test Passed"<<endl;
	else
		cout <<"Test Failed"<<endl;
	
}


void mainClasss::length_RefCount()
{
	str_in_refCount obj1;
	obj1.reserve(10);
	obj1.append('A');
	obj1.append('B');

	int len = obj1.length();
	if(len == 2)
		cout <<"Test Passed"<<endl;
	else
		cout <<"Test Failed"<<endl;

}


void mainClasss::length_RefLink()
{
	str_in_refLink* obj1 = new str_in_refLink();
	obj1->reserve(10);
	obj1->append('A');
	int len = obj1->length();
	if(len == 1)
		cout <<"Test Passed"<<endl;
	else
		cout <<"Test Failed"<<endl;
	
}



void mainClasss::Append_Copied()
{
	strCopied obj;
	obj.reserve(10);
	obj.append('A');
	int len = obj.length();
	if(len == 1)
		cout <<"Test Passed"<<endl;
	else
		cout <<"Test Failed"<<endl;
}



void mainClasss::Append_Owned()
{
	str_in_ownedString* obj1 = new str_in_ownedString();
	obj1->reserve(10);
	obj1->append('A');
	int len = obj1->length();
	if(len == 1)
		cout <<"Test Passed"<<endl;
	else
		cout <<"Test Failed"<<endl;
	
}


void mainClasss::Append_RefCount()
{
	str_in_refCount obj1;
	obj1.reserve(10);
	obj1.append('A');
	obj1.append('B');

	int len = obj1.length();
	if(len == 2)
		cout <<"Test Passed"<<endl;
	else
		cout <<"Test Failed"<<endl;

}


void mainClasss::Append_RefLink()
{
	str_in_refLink* obj1 = new str_in_refLink();
	obj1->reserve(1);
	obj1->append('A');
	int len = obj1->length();
	if(len == 1)
		cout <<"Test Passed"<<endl;
	else
		cout <<"Test Failed"<<endl;
	
}


void mainClasss::Print_Copied()
{
	strCopied obj;
	obj.reserve(1);
	obj.append('A');
	obj.print();

	if(obj.charAt(0) == 'A')
	{
		cout <<" Test Passed"<<endl;	
	}
	else
	{
		cout <<"Test Failed"<<endl;
	}
}



void mainClasss::Print_Owned()
{
	str_in_ownedString* obj1 = new str_in_ownedString();
	obj1->reserve(1);
	obj1->append('A');
	obj1->print();

	if(obj1->charAt(0) == 'A')
	{
		cout <<" Test Passed"<<endl;	
	}
	else
	{
		cout <<"Test Failed"<<endl;
	}
	
}


void mainClasss::Print_RefCount()
{
	str_in_refCount obj1;
	obj1.reserve(1);
	obj1.append('A');
	obj1.print();

	if(obj1.charAt(0) == 'A')
	{
		cout <<" Test Passed"<<endl;	
	}
	else
	{
		cout <<"Test Failed"<<endl;
	}

}


void mainClasss::Print_RefLink()
{
	str_in_refLink* obj1 = new str_in_refLink();
	obj1->reserve(1);
	obj1->append('A');
	
	obj1->print();

	if(obj1->charAt(0) == 'A')
	{
		cout <<" Test Passed"<<endl;	
	}
	else
	{
		cout <<"Test Failed"<<endl;
	}

	
}


int main(int argc, char const *argv[])
{

	mainClasss tmpObj;
cout<<"Testing First Phase\n";
	cout<<"\t\t|||||| ";tmpObj.cons_Copied_Pointer();
	cout<<"\t\t|||||| ";tmpObj.cons_Owned_Pointer();
	cout<<"\t\t|||||| ";tmpObj.cons_RefCount_Pointer();
	cout<<"\t\t|||||| ";tmpObj.cons_RefLink_Pointer();	
cout<<"\nTesting Length Phase\n";

	cout<<"\t\t|||||| ";tmpObj.length_Copied();
	cout<<"\t\t|||||| ";tmpObj.length_Owned();
	cout<<"\t\t|||||| ";tmpObj.length_RefCount();
	cout<<"\t\t|||||| ";tmpObj.length_RefLink();
cout<<"\nTesting Appending Phase\n";

	cout<<"\t\t|||||| ";tmpObj.Append_Copied();
	cout<<"\t\t|||||| ";tmpObj.Append_Owned();
	cout<<"\t\t|||||| ";tmpObj.Append_RefCount();
	cout<<"\t\t|||||| ";tmpObj.Append_RefLink();
cout<<"\nTesting Printing Phase\n";

	cout<<"\t\t|||||| ";tmpObj.Print_Copied();
	cout<<"\t\t|||||| ";tmpObj.Print_Owned();
	cout<<"\t\t|||||| ";tmpObj.Print_RefCount();
	cout<<"\t\t|||||| ";tmpObj.Print_RefLink();

	return 0;
}
